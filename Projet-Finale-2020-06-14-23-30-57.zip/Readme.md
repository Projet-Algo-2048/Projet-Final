# Projet Finale Algo : 2048
---
## information :
* language de programation : C
* Version : C89+
* Developpers : Theo Hopsore Kegme Jules-Antoine Brisset Joachim

## installation :
```sh
apt get install libsdl2-dev libsdl2-2.0-0
apt get install libsdl2-mixer-dev libsdl2-mixer-2.0-0
apt-get install libsdl2-ttf-dev libsdl2-ttf-2.0-0
```
## Execution :
```sh
make run
```
Pour plus d'information sur les commandes : 
```sh
make 
```
