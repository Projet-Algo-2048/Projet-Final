#ifndef SdlVar
#define SdlVar

#define WINDOW_LARGEUR 640
#define WINDOW_HAUTEUR 680

void SDL_EXITWITHERROR (const char *message);

#endif